<html>
  <body>
    <?php
      $caller = $_POST['caller'];

      echo "<h2>Radio Call-In Contest</h2>";
      echo "<strong>Today's winner: </strong>" . $caller . "<br />";
      echo "<em>Saved to server.</em>";
    ?>
  </body>
</html>
